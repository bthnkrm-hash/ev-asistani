# Ev Asistanı

> Sen düşünme, ben hatırlatırım.

Android + iOS için sade ev yönetimi uygulaması.

## V0.1
- Ana sayfa
- Aylık bütçe kartı
- Alışveriş bölümü
- Planlar
- Ayarlar
- Sistem açık/koyu tema
- Hızlı ekleme menüsü

## Çalıştırma
Flutter kurulu bir ortamda:

```bash
flutter pub get
flutter run
```
